import { useEffect, useState } from "react";
import { Menu, X, MessageCircle } from "lucide-react";
import logoImage from "../assets/logo.png";
import { useLanguage } from "../i18n/LanguageContext";
import LanguageSwitch from "../i18n/LanguageSwitch";

const WA_NUMBER = "6282110689827";

export default function Navbar() {
  const { t } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const waHref = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(t.navbar.waMessage)}`;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock body scroll saat mobile menu terbuka
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const handleLinkClick = () => setMenuOpen(false);

  // Menu terbuka = bar jadi solid (teks gelap) supaya logo & tombol tutup
  // tetap terbaca, apa pun yang ada di belakangnya.
  const solid = scrolled || menuOpen;

  // Tutup menu bila layar diputar / dilebarkan ke ukuran desktop.
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const onChange = () => mq.matches && setMenuOpen(false);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  // Esc menutup menu.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) =>
      e.key === "Escape" && setMenuOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  return (
    <header
      className={[
        "fixed top-0 left-0 right-0 z-50 transition-[background-color,box-shadow] duration-300",
        solid
          ? "bg-cream/95 backdrop-blur-sm shadow-[0_1px_0_rgba(27,67,50,0.08)]"
          : "bg-transparent",
      ].join(" ")}
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <div className="flex h-16 md:h-20 items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 shrink-0">
            <img
              src={logoImage}
              alt="Logo Al-Waliy"
              className="h-8 w-8 md:h-9 md:w-9 object-contain"
            />
            <span className="flex items-baseline gap-2">
              <span
                className={[
                  "font-heading text-lg md:text-xl font-extrabold tracking-tight transition-colors",
                  solid ? "text-forest" : "text-cream",
                ].join(" ")}
              >
                AL-WALIY
              </span>
              <span
                className={[
                  "text-[11px] md:text-xs font-medium uppercase tracking-[0.14em] transition-colors",
                  solid ? "text-gold" : "text-gold-light",
                ].join(" ")}
              >
                Maklon
              </span>
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {t.navbar.navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={[
                  "text-sm font-medium transition-colors hover:text-gold",
                  scrolled ? "text-ink" : "text-cream",
                ].join(" ")}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-5">
            <LanguageSwitch className={scrolled ? "text-ink" : "text-cream"} />
            <a
              href={waHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-[4px] bg-forest px-5 py-2.5 text-sm font-semibold text-cream transition-colors hover:bg-forest-light"
            >
              <MessageCircle size={16} strokeWidth={2.5} />
              {t.navbar.ctaLabel}
            </a>
          </div>

          {/* Mobile toggle */}
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={
              menuOpen ? t.navbar.closeMenuAria : t.navbar.openMenuAria
            }
            aria-expanded={menuOpen}
            className={[
              "md:hidden inline-flex h-11 w-11 -mr-2 items-center justify-center rounded-[4px] transition-colors",
              solid ? "text-forest" : "text-cream",
            ].join(" ")}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={[
          "md:hidden overflow-y-auto overscroll-contain bg-cream transition-[max-height,opacity] duration-300 ease-in-out",
          menuOpen
            ? "max-h-[calc(100dvh-4rem)] opacity-100"
            : "pointer-events-none max-h-0 opacity-0",
        ].join(" ")}
      >
        <nav
          aria-hidden={!menuOpen}
          className="flex flex-col gap-1 px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-2"
        >
          {t.navbar.navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={handleLinkClick}
              tabIndex={menuOpen ? 0 : -1}
              className="rounded-[4px] px-3 py-3.5 text-base font-medium text-ink transition-colors hover:bg-forest/5 hover:text-forest active:bg-forest/10"
            >
              {link.label}
            </a>
          ))}
          <div className="mt-2 px-3">
            <LanguageSwitch className="text-ink" />
          </div>
          <a
            href={waHref}
            target="_blank"
            rel="noopener noreferrer"
            onClick={handleLinkClick}
            tabIndex={menuOpen ? 0 : -1}
            className="mt-2 inline-flex items-center justify-center gap-2 rounded-[4px] bg-forest px-5 py-3.5 text-sm font-semibold text-cream"
          >
            <MessageCircle size={16} strokeWidth={2.5} />
            {t.navbar.ctaLabel}
          </a>
        </nav>
      </div>
    </header>
  );
}
