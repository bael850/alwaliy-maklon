import { useMemo, useState } from "react";
import {
  ImageIcon,
  Pill,
  FlaskConical,
  Droplets,
  Container,
  ArrowUpRight,
  type LucideIcon,
} from "lucide-react";
import Reveal from "../Reveal";
import SmartImage from "../SmartImage";
import Lightbox, { type LightboxItem } from "../Lightbox";
import { useLanguage } from "../../i18n/LanguageContext";

const WA_NUMBER = "6282110689827";

type Filter = "all" | "client" | "own";

interface WorkMeta {
  id: string;
  kind: "client" | "own";
  /** Indeks ke t.productTypes.types (Madu Herbal, Kapsul & Tablet, dst). */
  category: number;
  /**
   * PLACEHOLDER — path TANPA ekstensi ke public/images/work/<n>.
   * Taruh file .webp / .jpg / .png — otomatis kedeteksi.
   */
  imageBase: string;
}

// URUTAN HARUS 1:1 dengan t.whatWeDo.items di translations.ts.
const WORK_META: WorkMeta[] = [
  { id: "w1", kind: "client", category: 0, imageBase: "/images/work/1" },
  { id: "w2", kind: "own", category: 0, imageBase: "/images/work/2" },
  { id: "w3", kind: "client", category: 1, imageBase: "/images/work/3" },
  { id: "w4", kind: "own", category: 3, imageBase: "/images/work/4" },
  { id: "w5", kind: "client", category: 2, imageBase: "/images/work/5" },
  { id: "w6", kind: "own", category: 0, imageBase: "/images/work/6" },
  { id: "w7", kind: "client", category: 3, imageBase: "/images/work/7" },
  { id: "w8", kind: "own", category: 2, imageBase: "/images/work/8" },
];

const PRODUCT_ICONS: LucideIcon[] = [Container, Pill, FlaskConical, Droplets];
const FILTERS: Filter[] = ["all", "client", "own"];

export default function WhatWeDo() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<Filter>("all");
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const categories = t.productTypes.types;

  const visible = useMemo(
    () =>
      WORK_META.map((meta, i) => ({ meta, text: t.whatWeDo.items[i] })).filter(
        ({ meta }) => filter === "all" || meta.kind === filter,
      ),
    [filter, t.whatWeDo.items],
  );

  const counts: Record<Filter, number> = {
    all: WORK_META.length,
    client: WORK_META.filter((m) => m.kind === "client").length,
    own: WORK_META.filter((m) => m.kind === "own").length,
  };

  const lightboxItems: LightboxItem[] = visible.map(({ meta, text }) => ({
    id: meta.id,
    imageBase: meta.imageBase,
    title: text.name,
    meta: categories[meta.category].title,
    description:
      meta.kind === "client"
        ? `${t.whatWeDo.forClient}: ${text.client}`
        : t.whatWeDo.ownProduct,
    fallback: <ImageIcon size={56} strokeWidth={1.5} />,
  }));

  return (
    <section id="what" className="bg-cream py-20 md:py-28">
      <style>{`
        .work-in { animation: workIn 0.55s cubic-bezier(0.22, 1, 0.36, 1) backwards; }
        @keyframes workIn { from { opacity: 0; transform: translateY(18px) scale(0.97); } to { opacity: 1; transform: none; } }
        /* Perangkat dengan hover: caption muncul saat hover/fokus.
           Perangkat sentuh: caption selalu terlihat (nggak ada hover). */
        @media (hover: hover) and (pointer: fine) {
          .work-caption { opacity: 0; transform: translateY(10px); }
          .work-tile:hover .work-caption,
          .work-tile:focus-visible .work-caption { opacity: 1; transform: none; }
        }
        .work-caption { transition: opacity 0.3s ease, transform 0.4s cubic-bezier(0.22, 1, 0.36, 1); }
        @media (prefers-reduced-motion: reduce) {
          .work-in { animation: none; }
          .work-caption { transition: none; }
        }
      `}</style>

      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <Reveal>
          <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              <p className="mb-3 text-sm font-semibold uppercase tracking-[0.14em] text-gold">
                {t.whatWeDo.eyebrow}
              </p>
              <h2 className="font-heading text-3xl font-extrabold leading-tight text-forest md:text-5xl">
                {t.whatWeDo.heading}
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-ink/70 md:text-base">
                {t.whatWeDo.paragraph}
              </p>
            </div>

            {/* Filter */}
            <div
              role="group"
              aria-label={t.whatWeDo.filterAria}
              className="flex shrink-0 flex-wrap gap-2"
            >
              {FILTERS.map((f) => (
                <button
                  key={f}
                  type="button"
                  aria-pressed={filter === f}
                  onClick={() => {
                    setFilter(f);
                    setOpenIndex(null);
                  }}
                  className={[
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
                    filter === f
                      ? "border-forest bg-forest text-cream"
                      : "border-forest/25 text-forest hover:border-forest",
                  ].join(" ")}
                >
                  {t.whatWeDo.filters[f]}
                  <span
                    className={[
                      "text-xs tabular-nums",
                      filter === f ? "text-gold-light" : "text-forest/50",
                    ].join(" ")}
                  >
                    {counts[f]}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Galeri — key=filter supaya animasi masuk ulang tiap ganti filter */}
        <ul
          key={filter}
          className="mt-10 grid grid-cols-2 gap-3 md:mt-14 md:grid-cols-3 md:gap-4 lg:grid-cols-4"
        >
          {visible.map(({ meta, text }, i) => (
            <li
              key={meta.id}
              className="work-in"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <button
                type="button"
                onClick={() => setOpenIndex(i)}
                aria-label={`${t.whatWeDo.viewAriaPrefix}${text.name}`}
                className="work-tile group relative block aspect-[4/5] w-full overflow-hidden rounded-[4px] bg-forest/5 text-left"
              >
                <SmartImage
                  basePath={meta.imageBase}
                  alt=""
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  fallback={
                    <div className="flex h-full w-full items-center justify-center">
                      <ImageIcon
                        size={36}
                        strokeWidth={1.25}
                        className="text-forest/25"
                      />
                    </div>
                  }
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest/90 via-forest/15 to-transparent" />

                {/* Lencana asal produk */}
                <span
                  className={[
                    "absolute left-3 top-3 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.1em]",
                    meta.kind === "own"
                      ? "bg-gold text-forest"
                      : "bg-cream/90 text-forest",
                  ].join(" ")}
                >
                  {meta.kind === "own"
                    ? t.whatWeDo.ownBadge
                    : t.whatWeDo.clientBadge}
                </span>

                <div className="work-caption absolute inset-x-0 bottom-0 p-4">
                  <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-gold-light">
                    {categories[meta.category].title}
                  </p>
                  <p className="mt-1 font-heading text-sm font-bold leading-snug text-cream md:text-base">
                    {text.name}
                  </p>
                  {/* Nama klien HANYA tampil di Client Work */}
                  {meta.kind === "client" && (
                    <p className="mt-1 text-xs text-cream/70">
                      {t.whatWeDo.forClient} {text.client}
                    </p>
                  )}
                </div>
              </button>
            </li>
          ))}
        </ul>

        {/* Jenis produk yang bisa diproduksi + CTA konsultasi per jenis */}
        <div className="mt-20 border-t border-forest/15 pt-12 md:mt-28">
          <Reveal>
            <h3 className="font-heading text-2xl font-extrabold text-forest md:text-3xl">
              {t.productTypes.heading}
            </h3>
          </Reveal>
          <div className="mt-8 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((type, i) => {
              const Icon = PRODUCT_ICONS[i % PRODUCT_ICONS.length];
              return (
                <Reveal key={type.title} delay={i * 0.08}>
                  <div className="flex h-full flex-col">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-forest text-gold">
                      <Icon size={20} strokeWidth={2} />
                    </span>
                    <h4 className="mt-4 font-heading text-lg font-bold text-forest">
                      {type.title}
                    </h4>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-ink/70">
                      {type.desc}
                    </p>
                    <a
                      href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(
                        t.productTypes.waMessagePrefix + type.title,
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-forest underline underline-offset-4 transition-colors hover:text-gold"
                    >
                      {t.productTypes.ctaLabel}
                      <ArrowUpRight size={15} />
                    </a>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>

      <Lightbox
        items={lightboxItems}
        index={openIndex}
        onClose={() => setOpenIndex(null)}
        onIndexChange={setOpenIndex}
        labels={{
          close: t.whatWeDo.closeAria,
          prev: t.whatWeDo.prevAria,
          next: t.whatWeDo.nextAria,
        }}
      />
    </section>
  );
}
