import { useEffect, useState } from "react";
import Reveal from "../Reveal";
import { useLanguage } from "../../i18n/LanguageContext";

const ROTATE_MS = 5500;

export default function VisionMission() {
  const { t } = useLanguage();
  const missions = t.visionMission.missions;
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);

  // Misi berganti otomatis; berhenti saat hover/fokus atau reduced-motion.
  useEffect(() => {
    if (paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = setInterval(
      () => setActive((i) => (i + 1) % missions.length),
      ROTATE_MS,
    );
    return () => clearInterval(timer);
  }, [paused, missions.length]);

  const current = missions[active];

  return (
    <section id="vision" className="bg-cream py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <Reveal>
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.14em] text-gold">
            {t.visionMission.eyebrow}
          </p>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-forest/60">
            {t.visionMission.visionLabel}
          </p>
          <h2 className="mt-3 max-w-4xl font-heading text-3xl font-extrabold leading-[1.15] text-forest md:text-5xl">
            {t.visionMission.vision}
          </h2>
        </Reveal>

        <Reveal delay={0.1}>
          <div
            className="mt-16 grid gap-8 border-t border-forest/15 pt-10 md:grid-cols-12 md:gap-12"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            onFocus={() => setPaused(true)}
            onBlur={() => setPaused(false)}
          >
            <div className="md:col-span-4">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-forest/60">
                {t.visionMission.missionLabel}
              </p>
              <div
                role="tablist"
                aria-label={t.visionMission.missionLabel}
                className="mt-4 flex flex-col gap-2"
              >
                {missions.map((m, i) => (
                  <button
                    key={m.title}
                    type="button"
                    role="tab"
                    id={`mission-tab-${i}`}
                    aria-selected={i === active}
                    aria-controls="mission-panel"
                    aria-label={t.visionMission.selectAriaPrefix + m.title}
                    onClick={() => setActive(i)}
                    className={[
                      "rounded-[4px] border px-4 py-3 text-left transition-colors",
                      i === active
                        ? "border-forest bg-forest text-cream"
                        : "border-forest/15 text-forest hover:border-forest/40",
                    ].join(" ")}
                  >
                    <span className="text-sm font-semibold">{m.title}</span>
                  </button>
                ))}
              </div>
            </div>

            <div
              id="mission-panel"
              role="tabpanel"
              aria-labelledby={`mission-tab-${active}`}
              className="min-h-[11rem] md:col-span-8"
            >
              <div key={active} className="vm-in">
                <h3 className="font-heading text-2xl font-extrabold text-forest md:text-3xl">
                  {current.title}
                </h3>
                <p className="mt-4 max-w-xl text-base leading-relaxed text-ink/80 md:text-lg">
                  {current.desc}
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
